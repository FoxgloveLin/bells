Sound pack downloaded from Freesound
----------------------------------------

This pack of sounds contains sounds by the following user:
 - InspectorJ ( https://freesound.org/people/InspectorJ/ )

You can find this pack online at: https://freesound.org/people/InspectorJ/packs/19255/

License details
---------------

Attribution: http://creativecommons.org/licenses/by/3.0/


Sounds in this pack
-------------------

  * 339820__inspectorj__hand-bells-high-c-single.wav
    * url: https://freesound.org/s/339820/
    * license: Attribution
  * 339819__inspectorj__ab-single.wav
    * url: https://freesound.org/s/339819/
    * license: Attribution
  * 339818__inspectorj__hand-bells-g-single.wav
    * url: https://freesound.org/s/339818/
    * license: Attribution
  * 339817__inspectorj__gb-single.wav
    * url: https://freesound.org/s/339817/
    * license: Attribution
  * 339816__inspectorj__hand-bells-f-single.wav
    * url: https://freesound.org/s/339816/
    * license: Attribution
  * 339815__inspectorj__hand-bells-low-c-single.wav
    * url: https://freesound.org/s/339815/
    * license: Attribution
  * 339814__inspectorj__eb-single.wav
    * url: https://freesound.org/s/339814/
    * license: Attribution
  * 339813__inspectorj__hand-bells-d-single.wav
    * url: https://freesound.org/s/339813/
    * license: Attribution
  * 339812__inspectorj__hand-bells-e-single.wav
    * url: https://freesound.org/s/339812/
    * license: Attribution
  * 339811__inspectorj__bb-single.wav
    * url: https://freesound.org/s/339811/
    * license: Attribution
  * 339810__inspectorj__hand-bells-a-single.wav
    * url: https://freesound.org/s/339810/
    * license: Attribution
  * 339809__inspectorj__hand-bells-b-single.wav
    * url: https://freesound.org/s/339809/
    * license: Attribution
  * 339808__inspectorj__db-single.wav
    * url: https://freesound.org/s/339808/
    * license: Attribution


